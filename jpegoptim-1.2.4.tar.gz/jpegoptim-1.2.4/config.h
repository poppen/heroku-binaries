/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in. 
 * $Id: config.h.in,v 1.2 2002/12/04 13:17:58 tjko Exp $
 *
 */


/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 8

/* Define if you have the getopt_long function.  */
#define HAVE_GETOPT_LONG 1

/* Define if you have the <getopt.h> header file.  */
#define HAVE_GETOPT_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <libgen.h> header file.  */
#define HAVE_LIBGEN_H 1

/* Define if you have the jpeg library (-ljpeg).  */
#define HAVE_LIBJPEG 1



/* Define if you have broken jmorecfg.h (SGI's usually have this problem) */
/* #undef BROKEN_METHODDEF */

#define HOST_TYPE "x86_64-unknown-linux-gnu"


/* eof */
