Name: libpng
Summary: The PNG reference library
Authors: Glenn Randers-Pehrson et al.
Version: 1.4.12
License: the libpng license (zlib-like); see LICENSE
URL: http://libpng.org/

Changes:
- Defined PNG_USER_CONFIG in pngconf.h.
- Added pngusr.h.
