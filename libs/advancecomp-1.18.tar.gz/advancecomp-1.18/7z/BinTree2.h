#ifndef __BINTREE2__H
#define __BINTREE2__H

#undef BT_CLSID
#define BT_CLSID CLSID_CMatchFinderBT2

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT2

#include "BinTreeMF.h"

#endif

